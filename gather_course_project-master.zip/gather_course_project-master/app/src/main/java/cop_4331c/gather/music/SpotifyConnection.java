package cop_4331c.gather.music;

import kaaes.spotify.webapi.android.SpotifyService;
import kaaes.spotify.webapi.android.models.*;

/**
 * Created by ajariwinfield on 4/12/15.
 */
public class SpotifyConnection
{
    SpotifyService spotify;
    Host mHost;


    public SpotifyConnection(SpotifyService s, Host host)
    {
        spotify = s;
        mHost = host;
    }







    //Method to search for a song


}
