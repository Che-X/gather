# Gather

Gather is a social app designed to simplify and streamline the event planning process. We plan to
achieve this result by taking established resources for event planning and combining them into a
single interface. Allowing you to be much more efficient during the process. Services that will
be implemented are: Facebook, Instagram, Google Maps, Twitter, SMS, and your contact list.
Gather will also help you keep track of progress toward your final event plan by sectioning
your preparations and allowing you to update the status of each.  
